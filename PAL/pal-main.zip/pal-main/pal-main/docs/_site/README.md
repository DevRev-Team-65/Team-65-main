# PAL: Program-aided Language Models

```
@article{gao2022pal,
  author = {Gao, Luyu and Madaan, Aman and Zhou, Shuyan and Alon, Uri and Liu, Pengfei and Yang, Yiming and Callan, Jamie and Neubig, Graham},
  title = {PAL: Program-aided Language Models},
  publisher = {arXiv},
  year = {2022},
}
```